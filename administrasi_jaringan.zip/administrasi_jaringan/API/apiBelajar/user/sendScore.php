<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");


function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
} elseif ( !isset($_POST['idSiswa']) || !isset($_POST['idMateri']) ||!isset($_POST['tgl']) || !isset($_POST['skor']) ||
           empty(trim($_POST['idSiswa'])) || empty(trim($_POST['idMateri'])) || empty(trim($_POST['tgl'])) || empty(trim($_POST['skor']))
){
    $field = ['Fields' => ['idSiswa','idMateri','tgl','skor']];
    $returnData = msg(0,422,'Harap cek lagi field berikut',$field);
}else{
    $idSiswa = trim($_POST['idSiswa']);
    $idMateri = trim($_POST['idMateri']);
    $tgl = trim($_POST['tgl']);
    $skor = trim($_POST['skor']);

    $query = "INSERT INTO tb_nilai(id_siswa,id_materi,tgl,skor) VALUES(:ids,:idm,:tgl,:skor)";
    $statement = $conn->prepare($query);
    $statement->bindParam(":ids",$idSiswa);
    $statement->bindParam(":idm",$idMateri);
    $statement->bindParam(":tgl",$tgl);
    $statement->bindParam(":skor",$skor);
    $statement->execute();

    $returnData = msg(1,200,'Nilai ditambahkan ke database');

}

echo json_encode($returnData);
?>