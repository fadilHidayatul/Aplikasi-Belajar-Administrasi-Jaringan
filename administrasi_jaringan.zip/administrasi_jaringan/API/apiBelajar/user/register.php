<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Method: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization,X-Requested-With");


function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';

$database = new Database();
$conn = $database->getConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
} elseif ( !isset($_POST['nama']) || !isset($_POST['kelas']) || !isset($_POST['username']) || !isset($_POST['password']) ||
           empty(trim($_POST['nama'])) || empty(trim($_POST['kelas'])) || empty(trim($_POST['username'])) || empty(trim($_POST['password']))
){
    $field = ['Fields' => ['nama','kelas','username','password']];
    $returnData = msg(0,422,'Harap cek lagi field berikut',$field);
}else{
    try{
        $nama = trim($_POST['nama']);
        $kelas = trim($_POST['kelas']);
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        $query = "SELECT * FROM tb_siswa WHERE username=:un";
        $chk_un = $conn->prepare($query);
        $chk_un->bindParam(":un", $username);
        $chk_un->execute();
        $row = $chk_un->fetch(PDO::FETCH_ASSOC);

        if($username == $row['username']){
            $returnData = msg(0,300,'Username Sudah Ada,Silahkan Ganti Username');
        }else {
            

            $query = "INSERT INTO tb_siswa(nama,kelas,username,password) VALUES(:nama,:kelas,:username,:password)";
            $statement = $conn->prepare($query);
            $statement->bindParam(":nama", $nama);
            $statement->bindParam(":kelas", $kelas);
            $statement->bindParam(":username", $username);
            $statement->bindParam(":password", $password);
            $statement->execute();

            $returnData = msg(1,200,'Register Berhasil, Silahkan Login');
    }
    }catch(PDOException $e){
        $returnData = msg(0,500,$e->getMessage());
    }
}

echo json_encode($returnData);
?>
