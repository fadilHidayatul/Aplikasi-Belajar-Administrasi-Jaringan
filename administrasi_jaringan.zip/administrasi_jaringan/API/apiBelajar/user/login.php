<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json, charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

include_once '../class/database.php';
include_once '../class/jwthandler.php';

$database = new Database();
$conn = $database->getConnection();

$returnData = [];

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    $returnData = msg(0,404,'Page Not Found');
}elseif (!isset($_POST['username']) || !isset($_POST['password']) || 
empty(trim($_POST['username'])) || empty(trim($_POST['password']))
) {
    $field = ['Fields' => ['username','password']];
    $returnData = msg(0,300,'Harap cek field berikut',$field);
}else {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    try{
        $query = "SELECT * FROM tb_siswa WHERE username=:un";
        $getSiswa = $conn->prepare($query);
        $getSiswa->bindParam(":un", $username);
        $getSiswa->execute();

        if ($getSiswa->rowCount()) {
            $row = $getSiswa->fetch(PDO::FETCH_ASSOC);
            

            if ($password == $row['password']) {
                $returnData = [
                    'status' => 200,
                    'message' => 'Login Berhasil',
                    'data' => array(
                        'id_siswa' =>$row['id_siswa'],
                        'nama' => $row['nama'],
                        'kelas' => $row['kelas'],
                        'username' => $row['username']
                    )
                ];
            }else {
                $returnData = msg(0,422,'Password Salah');
            }

            
        }else{
            $returnData = msg(0,422,'Siswa belum mendaftar');
        }


    }catch(PDOException $e){
        $returnData = msg(0,500,$e->getMessage());
    }
}

echo json_encode($returnData);
?>